package com.example.ordermeal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderMealApplicationTests {

    @Test
    void contextLoads() {
    }

}